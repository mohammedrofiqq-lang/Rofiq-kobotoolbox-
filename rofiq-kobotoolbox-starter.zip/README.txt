# Rofiq Data — GitHub Pages starter

1. Create a GitHub repository named `rofiq-kobotoolbox`.
2. In the repository, choose **Add file → Upload files**.
3. Upload `index.html` from this package and commit the change.
4. Open **Settings → Pages**.
5. Under Build and deployment choose **Deploy from a branch**, branch `main`, folder `/(root)`, then Save.
6. After publishing, your site will be at:
   `https://YOUR-GITHUB-USERNAME.github.io/rofiq-kobotoolbox/`

This is a front-end visual prototype. Sign-in and registration are not connected to authentication or a database. Do not enter real passwords or personal/sensitive records. A secure backend, access controls, backups, and privacy review are needed before real data collection.
